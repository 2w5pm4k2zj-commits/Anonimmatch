import os
import logging
import asyncio
import time
from collections import deque
from typing import Optional

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    LabeledPrice, PreCheckoutQuery
)
from aiogram.enums import ChatType
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
import aiosqlite

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or 0)
DB_PATH = os.getenv("DB_PATH", "anonchat.db")
FREE_DAILY_MATCHES = int(os.getenv("FREE_DAILY_MATCHES", "30"))
PREMIUM_STARS = int(os.getenv("PREMIUM_STARS", "150"))  # Telegram Stars, monthly subscription
PREMIUM_DAYS = 30
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Set it in your hosting provider's environment variables.")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("anonchat")

bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()
waiting = deque()
waiting_lock = asyncio.Lock()
active_chats: dict[int, int] = {}  # user_id -> peer_id
last_sent: dict[int, float] = {}
START_TEXT = (
    "<b>АНОНИМ</b> — чат-рулетка\n\n"
    "Общайся с незнакомцами без показа им твоего Telegram-профиля.\n"
    "Выбери поиск, дождись собеседника и начинай общение.\n\n"
    "• Никнеймы и номера телефонов не требуются\n"
    "• В любой момент можно завершить чат или пожаловаться\n"
    "• Не отправляй личные данные незнакомцам\n\n"
    "<i>Для пользователей 18+. Это не абсолютная анонимность: Telegram и оператор бота обрабатывают технические данные.</i>"
)

def kb_main():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔎 Найти собеседника", callback_data="find")],
        [InlineKeyboardButton(text="⭐ Premium за Stars", callback_data="premium"),
         InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help")],
        [InlineKeyboardButton(text="🛑 Правила и безопасность", callback_data="rules")]
    ])

def kb_chat():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏭ Следующий", callback_data="next"),
         InlineKeyboardButton(text="✖ Завершить", callback_data="stop")],
        [InlineKeyboardButton(text="🚩 Пожаловаться", callback_data="report")]
    ])

def kb_cancel_search():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Отменить поиск", callback_data="cancel_find")]
    ])

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            language TEXT DEFAULT 'ru',
            premium_until INTEGER DEFAULT 0,
            joined_at INTEGER NOT NULL,
            banned INTEGER DEFAULT 0,
            matches_date TEXT DEFAULT '',
            matches_count INTEGER DEFAULT 0
        )""")
        await db.execute("""CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reporter_id INTEGER NOT NULL,
            reported_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            note TEXT DEFAULT ''
        )""")
        await db.execute("""CREATE TABLE IF NOT EXISTS blocks (
            user_id INTEGER NOT NULL,
            blocked_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            PRIMARY KEY(user_id, blocked_id)
        )""")
        await db.execute("""CREATE TABLE IF NOT EXISTS payments (
            charge_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            created_at INTEGER NOT NULL
        )""")
        await db.commit()

async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id, language, premium_until, banned, matches_date, matches_count FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row

async def ensure_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO users(user_id, joined_at) VALUES(?,?)", (user_id, int(time.time())))
        await db.commit()
    return await get_user(user_id)

async def is_premium(user_id: int) -> bool:
    row = await get_user(user_id)
    return bool(row and row[2] > int(time.time()))

async def is_banned(user_id: int) -> bool:
    row = await get_user(user_id)
    return bool(row and row[3])

async def match_limit_ok(user_id: int) -> bool:
    if await is_premium(user_id):
        return True
    row = await get_user(user_id)
    if not row:
        return True
    today = time.strftime("%Y-%m-%d", time.gmtime())
    async with aiosqlite.connect(DB_PATH) as db:
        if row[4] != today:
            await db.execute("UPDATE users SET matches_date=?, matches_count=0 WHERE user_id=?", (today, user_id))
            await db.commit()
            return True
        return row[5] < FREE_DAILY_MATCHES

async def increment_match_count(user_id: int):
    today = time.strftime("%Y-%m-%d", time.gmtime())
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""UPDATE users SET matches_date=?, matches_count=CASE WHEN matches_date=? THEN matches_count+1 ELSE 1 END WHERE user_id=?""", (today, today, user_id))
        await db.commit()

async def remove_from_queue(user_id: int):
    async with waiting_lock:
        try:
            waiting.remove(user_id)
        except ValueError:
            pass

async def end_chat(user_id: int, notify_peer: bool = True):
    peer = active_chats.pop(user_id, None)
    if peer is not None:
        active_chats.pop(peer, None)
        if notify_peer:
            try:
                await bot.send_message(peer, "Собеседник завершил чат.", reply_markup=kb_main())
            except Exception:
                pass
    return peer

async def find_partner(user_id: int) -> Optional[int]:
    await remove_from_queue(user_id)
    async with waiting_lock:
        while waiting:
            candidate = waiting.popleft()
            if candidate == user_id:
                continue
            if candidate in active_chats or await is_banned(candidate):
                continue
            async with aiosqlite.connect(DB_PATH) as db:
                cur = await db.execute("SELECT blocked_id FROM blocks WHERE user_id=? UNION SELECT user_id FROM blocks WHERE blocked_id=?", (user_id, user_id))
                blocked = {r[0] for r in await cur.fetchall()}
            if candidate in blocked:
                continue
            active_chats[user_id] = candidate
            active_chats[candidate] = user_id
            await increment_match_count(user_id)
            await increment_match_count(candidate)
            return candidate
        waiting.append(user_id)
        return None

async def start_search(user_id: int, message: Message):
    await ensure_user(user_id)
    if await is_banned(user_id):
        await message.answer("Доступ к боту ограничен из-за нарушений правил.")
        return
    if user_id in active_chats:
        await message.answer("Ты уже в чате.", reply_markup=kb_chat())
        return
    if not await match_limit_ok(user_id):
        await message.answer(
            f"На сегодня закончились бесплатные поиски ({FREE_DAILY_MATCHES}/день).\n"
            "Оформи Premium за Stars, чтобы снять дневной лимит.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="⭐ Открыть Premium", callback_data="premium")],
                [InlineKeyboardButton(text="↩️ В меню", callback_data="menu")]
            ])
        )
        return
    partner = await find_partner(user_id)
    if partner:
        try:
            await bot.send_message(user_id, "🎉 Собеседник найден! Можешь писать сообщение. Не передавай личные данные.", reply_markup=kb_chat())
            await bot.send_message(partner, "🎉 Собеседник найден! Можешь писать сообщение. Не передавай личные данные.", reply_markup=kb_chat())
        except Exception:
            await end_chat(user_id, notify_peer=False)
    else:
        await message.answer("🔎 Ищем собеседника… Когда кто-то подключится, я сообщу.", reply_markup=kb_cancel_search())

@dp.message(CommandStart())
async def start(message: Message):
    if message.chat.type != ChatType.PRIVATE:
        return
    row = await ensure_user(message.from_user.id)
    if row and row[3]:
        await message.answer("Доступ к боту ограничен.")
        return
    await message.answer(START_TEXT, reply_markup=kb_main())

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(
        "Команды:\n/start — меню\n/find — найти собеседника\n/stop — завершить чат\n/language — выбрать язык интерфейса\n/rules — правила\n\n"
        "Бот пересылает поддерживаемые сообщения через себя. Не отправляй пароли, документы, адрес, банковские данные или интимные материалы."
    , reply_markup=kb_main())

@dp.message(Command("find"))
async def find_cmd(message: Message):
    await start_search(message.from_user.id, message)

@dp.message(Command("stop"))
async def stop_cmd(message: Message):
    uid = message.from_user.id
    await remove_from_queue(uid)
    peer = await end_chat(uid)
    await message.answer("Чат завершён." if peer else "Поиск/чат остановлен.", reply_markup=kb_main())

@dp.message(Command("rules"))
async def rules_cmd(message: Message):
    await message.answer(
        "<b>Правила безопасности</b>\n\n"
        "1. Только для пользователей 18+.\n"
        "2. Не угрожай, не преследуй, не публикуй чужие личные данные.\n"
        "3. Не отправляй деньги незнакомцам и не переходи по подозрительным ссылкам.\n"
        "4. Не делись телефоном, адресом, документами или паролями.\n"
        "5. Используй «Пожаловаться», если собеседник нарушает правила.\n\n"
        "Жалоба сохраняет технические ID участников и время. В первой версии содержимое переписки не сохраняется автоматически.",
        reply_markup=kb_main()
    )

@dp.callback_query(F.data == "menu")
async def menu_cb(c: CallbackQuery):
    await c.message.answer(START_TEXT, reply_markup=kb_main())
    await c.answer()

@dp.callback_query(F.data == "help")
async def help_cb(c: CallbackQuery):
    await c.message.answer("Найди собеседника, общайся через бота и используй кнопки управления. /stop завершает чат. Жалобы помогают модерации.", reply_markup=kb_main())
    await c.answer()

@dp.callback_query(F.data == "rules")
async def rules_cb(c: CallbackQuery):
    await rules_cmd(c.message)
    await c.answer()

@dp.callback_query(F.data == "find")
async def find_cb(c: CallbackQuery):
    await c.answer()
    await start_search(c.from_user.id, c.message)

@dp.callback_query(F.data == "cancel_find")
async def cancel_find(c: CallbackQuery):
    await remove_from_queue(c.from_user.id)
    await c.message.answer("Поиск отменён.", reply_markup=kb_main())
    await c.answer()

@dp.callback_query(F.data == "stop")
async def stop_cb(c: CallbackQuery):
    uid = c.from_user.id
    await remove_from_queue(uid)
    peer = await end_chat(uid)
    await c.message.answer("Чат завершён." if peer else "Поиск остановлен.", reply_markup=kb_main())
    await c.answer()

@dp.callback_query(F.data == "next")
async def next_cb(c: CallbackQuery):
    uid = c.from_user.id
    await remove_from_queue(uid)
    await end_chat(uid)
    await c.answer("Ищем нового собеседника…")
    await start_search(uid, c.message)

@dp.callback_query(F.data == "report")
async def report_cb(c: CallbackQuery):
    uid = c.from_user.id
    peer = active_chats.get(uid)
    if peer is None:
        await c.answer("Сейчас нет активного чата.", show_alert=True)
        return
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO reports(reporter_id, reported_id, created_at) VALUES(?,?,?)", (uid, peer, int(time.time())))
        await db.execute("INSERT OR IGNORE INTO blocks(user_id, blocked_id, created_at) VALUES(?,?,?)", (uid, peer, int(time.time())))
        await db.commit()
    await end_chat(uid)
    if ADMIN_ID:
        try:
            await bot.send_message(ADMIN_ID, f"🚩 Жалоба: reporter_id={uid}, reported_id={peer}. Проверь базу reports.")
        except Exception:
            pass
    await c.message.answer("Жалоба отправлена. Этот собеседник заблокирован для тебя.", reply_markup=kb_main())
    await c.answer("Спасибо за сообщение.")

@dp.callback_query(F.data == "premium")
async def premium_cb(c: CallbackQuery):
    await c.answer()
    await c.message.answer(
        f"<b>⭐ Premium — {PREMIUM_STARS} Stars / 30 дней</b>\n\n"
        f"• Без дневного лимита на поиск\n"
        f"• Поддержка развития бота\n\n"
        "Это первая версия подписки: после оплаты доступ включается на 30 дней. "
        "Автоматическое продление в этой версии не включено.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"⭐ Купить за {PREMIUM_STARS} Stars", callback_data="buy_premium")],
            [InlineKeyboardButton(text="↩️ Назад", callback_data="menu")]
        ])
    )

@dp.callback_query(F.data == "buy_premium")
async def buy_premium(c: CallbackQuery):
    await c.answer()
    prices = [LabeledPrice(label="ANONIM Premium — 30 дней", amount=PREMIUM_STARS)]
    await bot.send_invoice(
        chat_id=c.from_user.id,
        title="ANONIM Premium",
        description="30 дней без дневного лимита поиска собеседников.",
        payload=f"premium30:{c.from_user.id}:{int(time.time())}",
        currency="XTR",
        prices=prices,
        provider_token=""
    )

@dp.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery):
    await q.answer(ok=True)

@dp.message(F.successful_payment)
async def successful_payment(message: Message):
    payment = message.successful_payment
    uid = message.from_user.id
    if payment.currency != "XTR":
        await message.answer("Платёж получен, но валюта не распознана. Свяжись с поддержкой.")
        return
    now = int(time.time())
    until = max(now, (await get_user(uid))[2]) + PREMIUM_DAYS * 86400
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO payments(charge_id,user_id,amount,created_at) VALUES(?,?,?,?)",
                         (payment.telegram_payment_charge_id, uid, payment.total_amount, now))
        await db.execute("UPDATE users SET premium_until=? WHERE user_id=?", (until, uid))
        await db.commit()
    await message.answer("⭐ Premium активирован на 30 дней! Спасибо за поддержку.", reply_markup=kb_main())

@dp.message(Command("language"))
async def language_cmd(message: Message):
    await message.answer("Язык интерфейса пока русский. Украинская локализация будет добавлена в следующей версии.")

@dp.message()
async def relay_message(message: Message):
    if message.chat.type != ChatType.PRIVATE or not message.from_user:
        return
    uid = message.from_user.id
    await ensure_user(uid)
    if message.text and message.text.startswith("/"):
        return
    if await is_banned(uid):
        await message.answer("Доступ ограничен.")
        return
    peer = active_chats.get(uid)
    if peer is None:
        await message.answer("Сначала найди собеседника кнопкой ниже.", reply_markup=kb_main())
        return
    now = time.monotonic()
    if now - last_sent.get(uid, 0) < 0.45:
        await message.answer("Не так быстро — подожди секунду.")
        return
    last_sent[uid] = now
    try:
        if message.text:
            await bot.send_message(peer, message.text, reply_markup=kb_chat())
        elif message.sticker:
            await bot.send_sticker(peer, message.sticker.file_id, reply_markup=kb_chat())
        elif message.photo:
            await bot.send_photo(peer, message.photo[-1].file_id, caption=message.caption or "", reply_markup=kb_chat())
        elif message.video:
            await bot.send_video(peer, message.video.file_id, caption=message.caption or "", reply_markup=kb_chat())
        elif message.voice:
            await bot.send_voice(peer, message.voice.file_id, caption=message.caption or "", reply_markup=kb_chat())
        elif message.animation:
            await bot.send_animation(peer, message.animation.file_id, caption=message.caption or "", reply_markup=kb_chat())
        elif message.document:
            await bot.send_document(peer, message.document.file_id, caption=message.caption or "", reply_markup=kb_chat())
        else:
            await message.answer("Этот тип сообщения пока не поддерживается. Отправь текст, фото, видео, голосовое или стикер.")
    except Exception:
        await message.answer("Не удалось доставить сообщение. Возможно, собеседник завершил чат.")
        await end_chat(uid, notify_peer=False)
        await message.answer("Вернись в меню и найди нового собеседника.", reply_markup=kb_main())

async def main():
    await init_db()
    log.info("Starting anonymous chat bot")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
